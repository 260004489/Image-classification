# -*- coding: utf-8 -*-
"""
Created on Tue Oct 12 21:24:53 2021

@author: duanw
"""

import tensorflow as tf    
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Activation, Flatten
from tensorflow.keras.layers import Conv2D, MaxPooling2D
import pickle


pickle_in = open("x.pickle","rb")
X = pickle.load(pickle_in)

pickle_in = open("y.pickle","rb")
y = pickle.load(pickle_in)

X = X/255.0

dense_layers = [0]
layer_sizes = [64]
conv_layers = [3]

for dense_layer in dense_layers:
    for layer_size in layer_sizes:
        for conv_layer in conv_layers:
            model = Sequential()

            model.add(Conv2D(layer_size, (3, 3), input_shape=X.shape[1:]))
            model.add(Activation('relu'))
            model.add(MaxPooling2D(pool_size=(2, 2)))

            for l in range(conv_layer-1):
                model.add(Conv2D(layer_size, (3, 3)))
                model.add(Activation('relu'))
                model.add(MaxPooling2D(pool_size=(2, 2)))

            model.add(Flatten())

            for _ in range(dense_layer):
                model.add(Dense(layer_size))
                model.add(Activation('relu'))

            model.add(Dense(1))
            model.add(Activation('sigmoid'))

   
            model.compile(loss='binary_crossentropy',
                          optimizer='adam',
                          metrics=['accuracy'],
                          )
            model.fit(X, y,
                          batch_size=4,
                          epochs=10,
                          validation_split=0.3,)

model.save('64x3-CNN.model')



