# -*- coding: utf-8 -*-
"""
Created on Sat Oct  9 00:15:26 2021

@author: duanw
"""

from tensorflow.keras.models import load_model
import numpy as np
import cv2
import io 
from PIL import Image
import json
from urllib.request import urlopen
import base64


model = load_model("64x3-CNN.model")
CATEGORIES = ["banana", "paper bag"]  
img_fields = {"img_id": 0, "img_name": "abc", "img_type":"abc", "img_format":"abc"}

with urlopen("http://68.66.205.76:6000/images") as response:
    source = response.read()

data = json.loads(source)

def img_data_collect(data):
    img_fields["img_id"]=data[img_index]["img_id"]
    img_fields["img_name"]=data[img_index]["img_name"]
    img_fields["img_format"]=data[img_index]["img_format"]
    img_fields["img_type"]=data[img_index]["img_type"]
     
def pdt_result(data):
    IMG_SIZE = 70
    img_decode = base64.b64decode(data[img_index]["img_format"])
    image = Image.open(io.BytesIO(img_decode))
    img = image.convert('L')
    img_array = np.asarray(img)
    new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))
    img_type = new_array.astype('float')
    img = img_type.reshape(-1, IMG_SIZE, IMG_SIZE, 1)   
    prediction = model.predict([img]) 
    img_data_collect(data)
    string = "The image id #" + str(img_fields["img_id"]) + " was predicted to be " + CATEGORIES[int(prediction[0][0])]
    return string


for img_index in range(len(data)):
   print(pdt_result(data))






    