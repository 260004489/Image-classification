# -*- coding: utf-8 -*-
"""
Created on Fri Nov  5 12:49:58 2021

@author: duanw
"""

data = {
    "img_id": 1,
    "img_name": "dog",
    "img_type": "jpg",
    "img_format": "abc"
}

goal_data = [["img_id",1],["img_name"],"dog",]

data_list = list(data.items())
        
print(data_list)