# -*- coding: utf-8 -*-
"""
Created on Fri Oct 15 21:17:57 2021

@author: duanw
"""

from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_restful import Api, Resource
import base64
import numpy as np
import cv2
import io 
from PIL import Image
from tensorflow.keras.models import load_model

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///img.db'
db = SQLAlchemy(app)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
ma = Marshmallow(app)
api = Api(app)
CATEGORIES = ["banana", "paper bag"]  
model = load_model("64x3-CNN.model")

class Img(db.Model):
    __tablename__ = "images"
    img_id = db.Column(db.Integer, primary_key=True)
    img_name = db.Column(db.Text, nullable=False)
    img_type = db.Column(db.Text, nullable=False)
    img = db.Column(db.Text, unique=True, nullable=False)

    def __repr__(self):
        return '<Image %d>' % self.img_id
    
class ImgSchema(ma.Schema):
    class Meta:
        fields = ("img_id", "img_name", "img_type", "img")
        model = Img

img_schema = ImgSchema()
imgs_schema = ImgSchema(many=True)

def pdt_result(data):
    IMG_SIZE = 70
# =============================================================================
#     img_decode = base64.b64decode(data)
# =============================================================================

    image = Image.open(io.BytesIO(data))
    img = image.convert('L')
    img_array = np.asarray(img)
    new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))
    img_type = new_array.astype('float')
    img = img_type.reshape(-1, IMG_SIZE, IMG_SIZE, 1)   
    prediction = model.predict([img]) 
    string = CATEGORIES[int(prediction[0][0])]
    return string

class ImageListResource(Resource):
    def post(self):

# =============================================================================
#         new_image = Img(
#                 img_id = request.json['img_id'],
#                 img_name = request.json['img_name'],
#                 img_type = request.json['img_type'],
#                 img = request.json['img']
#                 )
# =============================================================================
        img_r = request.files['img'].read()
        temp = pdt_result(img_r)
        new_image = Img(
                img_id = request.form['img_id'],
                img_name = request.form['img_name'],
                img_type = request.form['img_type'],
                img = temp
                )


        
        
        
        return img_schema.dump(new_image)
# =============================================================================
#     def get(self):
#         images = Img.query.all()
#         return imgs_schema.dump(images)
# 
# =============================================================================

# =============================================================================
#         db.session.add(new_image)
#         db.session.commit()
# =============================================================================
        

        #return ({'img': request.json['img']})
        #return (request.json['img'])
    
    
# =============================================================================
# class ImageResource(Resource):
# =============================================================================

# =============================================================================
#     def get(self, img_id):
#         image = Img.query.get_or_404(img_id)
#         return img_schema.dump(image)
#         #return "Image in base64: " + image.img
# 
#     def patch(self, img_id):
#         image = Img.query.get_or_404(img_id)
#         
#         if 'img_name' in request.json:
#             image.img_name = request.json['img_name']
# 
#         if 'img_type' in request.json:
#             image.img_type = request.json['img_type']
# 
#         if 'img' in request.json:
#             image.img = request.json['img']
# 
#         db.session.commit()
#         return img_schema.dump(image)
# 
# 
#     def delete(self, img_id):
#         image = Img.query.get_or_404(img_id)
#         db.session.delete(image)
#         db.session.commit()
#         return '', 204    
# =============================================================================
    
api.add_resource(ImageListResource, '/images')
# =============================================================================
# api.add_resource(ImageResource, '/images/<int:img_id>')
# =============================================================================
    
    
    
    
    
    
    
    
    
    
    
    