# -*- coding: utf-8 -*-
"""
Created on Sat Oct 16 17:47:57 2021

@author: duanw
"""

import sqlite3

connect = sqlite3.connect("img.db")

c = connect.cursor()

c.execute("""CREATE TABLE images (
            img_id integer,
            img_format text,
            img_name text,
            img_type text
            )""")

connect.commit()
connect.close()