# -*- coding: utf-8 -*-
"""
Created on Fri Oct 15 21:12:20 2021

@author: duanw
"""


from main import app
if __name__ == "__main__":
	app.run()
